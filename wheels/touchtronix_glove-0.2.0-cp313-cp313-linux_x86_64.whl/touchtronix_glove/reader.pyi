from collections.abc import Iterator, Sequence
from types import TracebackType

from touchtronix_glove._core import GloveFrame

class GloveReader:
    def __init__(
        self,
        port: str | Sequence[str],
        baudrate: int = 6000000,
    ) -> None: ...
    def __enter__(self) -> GloveReader: ...  # noqa: PYI034 - Python 3.10 has no typing.Self.
    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None: ...
    def connect(self) -> None: ...
    def disconnect(self) -> None: ...
    def read_frame(self) -> GloveFrame | None: ...
    def stream(self) -> Iterator[GloveFrame]: ...
