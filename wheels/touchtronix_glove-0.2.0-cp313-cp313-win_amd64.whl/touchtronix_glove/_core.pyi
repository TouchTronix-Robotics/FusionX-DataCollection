from collections.abc import Callable, Sequence
from dataclasses import dataclass
from typing import Literal

BAUDRATE: int
FRAME_LEN: int

@dataclass(frozen=True)
class TactileData:
    thumb: tuple[tuple[int, int, int], ...] | None = None
    index: tuple[tuple[int, int, int], ...] | None = None
    middle: tuple[tuple[int, int, int], ...] | None = None
    ring: tuple[tuple[int, int, int], ...] | None = None
    little: tuple[tuple[int, int, int], ...] | None = None
    palm: tuple[tuple[int | None, ...], ...] | None = None

@dataclass(frozen=True)
class BendData:
    thumb: tuple[int, int]
    index: tuple[int, int]
    middle: tuple[int, int]
    ring: tuple[int, int]
    little: tuple[int, int]

@dataclass(frozen=True)
class IMUData:
    quaternion: tuple[float, float, float, float]
    gyro: tuple[float, float, float] | None
    accel: tuple[float, float, float] | None
    magnetometer: tuple[float, float, float] | None

@dataclass(frozen=True)
class GloveFrame:
    hand: str
    tactile: TactileData
    imu: IMUData | None
    host_timestamp_ns: int
    bend: BendData | None = None
    @property
    def timestamp(self) -> float: ...

class TactileGloveReader:
    def __init__(
        self,
        port: str,
        baudrate: int = 6000000,
        hand: str | None = None,
        *,
        timeout: float = 0.1,
        imu_bytes: Literal[0, 16, 40, 52] = 52,
    ) -> None: ...
    def connect(self) -> None: ...
    def disconnect(self) -> None: ...
    def read_frame(self, *, wait: bool = True) -> GloveFrame | None: ...
    def run(self, callback: Callable[[GloveFrame], None]) -> None: ...

class TactileGloveStream:
    def __init__(
        self,
        ports: str | Sequence[str],
        baudrate: int = 6000000,
        hand: str | None = None,
        *,
        timeout: float = 0.1,
        imu_bytes: Literal[0, 16, 40, 52] = 52,
    ) -> None: ...
    def connect(self) -> None: ...
    def disconnect(self) -> None: ...
    def read_frame(self) -> GloveFrame | None: ...
